# Odds App
あなた専用のオッズ取得・期待値表示Webアプリ（Next.jsベース）