
export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Odds App</h1>
      <p>このページはあなた専用のオッズ取得アプリです。</p>
    </div>
  );
}
